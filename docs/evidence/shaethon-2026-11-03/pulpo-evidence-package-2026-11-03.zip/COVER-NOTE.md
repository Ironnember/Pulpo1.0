# Pulpo-Preview — independent evidence package (reproduction run)

Prepared by SHAETHON AI for Austin Irvan / Iron & Ember, in fulfilment of
the Nov 3, 2026 commitment to share the harness and raw results behind our
31 Pulpo boundary probes.

## What this is — and what it is not

This is a **reproduction run, executed November 3, 2026**. It is **not** the
original October 31, 2026 run's output. The Oct 31 evaluation ran in an
ephemeral sandbox whose working files — the probe script, the downloaded
archive, and the raw console logs — were not retained. The Oct 31 *results*
survive in full in our results write-up (already shared with Austin in the
Nov 3 packet), but rather than ask anyone to take a summary on faith, we
re-ran everything against the identical source and packaged the fresh raw
artifacts here, labelled for exactly what they are.

## Source under test — provenance

- Repository: `spikediegel-prog/Pulpo-Preview`, pre-release
  `pulpo-linux-v0.1.0-ubuntu-evaluation.20261031` (the same release asset
  form the Oct 31 run evaluated — not the canonical `Ironnember/Pulpo1.0`
  main tree; our results remain Preview evidence, plainly).
- Commit: `ec5270876c6db57c2cf58d9383001b1d7a9e08c1`
- Archive: `pulpo-linux-source-ec5270876c6db57c2cf58d9383001b1d7a9e08c1.tar.gz`
- Archive SHA-256: `358c2c6322c7ce22fb5a735cee2aa6ab448231a0b3a8a86c4de1c9cbcd21ffb2`
  — computed on the downloaded file; matches the publisher-stated hash on
  the release page. (SHAETHON's Oct 31 log records that the hash matched
  the published hash exactly before anything was run; the hex value itself
  was not carried into our write-up, so verification here was anchored to
  the publisher-stated hash on the release page.)
- No Pulpo code was modified. No Pulpo system, account, or file of
  Austin's was accessed — everything ran against a local copy.

## Environment

- Linux VM, run as root (same posture as Oct 31), Python 3.12.3, fresh
  virtual environment; dependencies installed per the repository's own
  pyprojects (core plus the authority-service and custody-service test
  extras).
- Scrubbed process environment (`env -i`, minimal PATH, sandbox HOME) —
  the Oct 31 method. The suite log's header explains why this matters: in
  an ambient shell environment, Pulpo's own fail-closed transport check
  adds spurious errors. The enclosed log is the scrubbed run.

## Headline results — as they landed in this run

- **Core test suite: 1,024 tests ran — 940 passed, 56 skipped, 4 failed,
  24 errored** (77.8 s). Oct 31: 1,024 ran — 936 passed, 60 skipped,
  4 failed, 24 errored. The only delta: four tests that skipped on Oct 31
  ran and passed here. All failures/errors sit outside the permit,
  governance, and verifier kernel suites, in the same environment-bound
  clusters as Oct 31 (live-git-checkout requirements, root/permission
  posture, WSL packaging, volatile-storage disk fixture). Full detail in
  `comparison.md` and the raw log.
- **Boundary probes: 31 held, 0 broke, 0 not run** — identical to Oct 31.
- Additional suites (not part of the Oct 31 headline): constitutional
  sequence OK; authority-service 70 ran, OK (4 skipped); custody-service
  50 ran, OK.

## How to read the enclosed files

- `COVER-NOTE.md` — this note.
- `comparison.md` — fresh results set against the Oct 31 record, with the
  one divergence flagged at the top, failure/error clusters by module and
  cause, and the per-probe table.
- `probe_harness.py` — the 31-probe harness, re-implemented from the
  Oct 31 write-up's specification against the kernel's public API (plus
  probe 31, the same explicitly-labelled white-box audit-tamper check as
  the original). The kernel secret in it is a throwaway created for the
  harness, published deliberately so the run is reproducible; it protects
  nothing. Run it inside an environment with the Pulpo package importable.
- `probes-raw-output.txt` — complete raw output of the probe run,
  including each probe's observed behaviour and the kernel's denial
  reasons.
- `probes-results.json` — the same results, machine-readable.
- `suite-raw-output.txt` — complete raw output of the full suite run
  (core, constitutional, authority-service, custody-service), with the
  commands, versions, and provenance recorded in its header. Absolute
  local paths in tracebacks have been replaced with `<PULPO_SRC>` /
  `<RERUN_DIR>` placeholders; nothing else was altered.

## Limits

- This package evidences Pulpo-**Preview** at commit `ec52708`, as did the
  Oct 31 run. It says nothing about canonical Pulpo main (`6b3caac`),
  which still has no independent executor; the offered second pass stands.
- The suite failures/errors above are environment-bound, as they were on
  Oct 31; the clean closure for them is the already-discussed rerun as a
  non-root user in a live git clone.
- Claim classification, in Pulpo's own convention: the enclosed results
  are **Recorded** (raw artifacts enclosed; reproducible from the stated
  hash and harness). Interpretations in `comparison.md` are labelled
  against the Oct 31 record they compare to.

SHAETHON AI — No permit, no execution.
