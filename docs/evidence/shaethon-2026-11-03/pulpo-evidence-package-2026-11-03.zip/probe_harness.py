#!/usr/bin/env python3
"""SHAETHON AI — Pulpo-Preview adversarial boundary probes (reproduction run).

Re-implements the 31 boundary probes of the Oct 31, 2026 SHAETHON evaluation
against Pulpo-Preview commit ec5270876c6db57c2cf58d9383001b1d7a9e08c1,
using only the governance kernel's public API (plus ONE explicitly labelled
white-box audit-tamper check, probe 31, exactly as in the original run).

Probe definitions are taken from the Oct 31 results write-up
("Pulpo — Independent Test Results (Run by SHAETHON AI)", Part 2).

Verdicts:
  HELD    — kernel behaviour matched the Oct 31 recorded outcome
            (attack refused / control behaved as specified).
  BROKE   — behaviour diverged in the attacker's favour, or a control failed.
  NOT RUN — the probe could not be implemented/executed as specified;
            the reason is recorded. Never silently skipped.

The kernel secret used below is a throwaway value created for this harness;
it protects nothing and is published with the harness for reproducibility.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import sys
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from pulpo.kernel import AgentGrant, GovernanceKernel, Intent, Policy
from pulpo.state import InMemoryKernelState, SQLiteKernelState

SECRET = b"shaethon-probe-harness-secret-v1"  # throwaway, see docstring
OTHER_SECRET = b"shaethon-probe-harness-other-secret"
ATTACKER_SECRET = b"attacker-controlled-key-material"

BASE = Intent(
    principal="alice",
    action="read",
    resource="file:/data/report.txt",
    cost=10,
    session_id="sess-1",
)

RESULTS: list[dict] = []


def record(pid: str, group: str, name: str, expected: str, observed: str, verdict: str) -> None:
    RESULTS.append(
        {
            "id": pid,
            "group": group,
            "name": name,
            "expected_oct31": expected,
            "observed": observed,
            "verdict": verdict,
        }
    )
    print(f"[{pid}] {name}\n     expected (Oct 31): {expected}\n     observed: {observed}\n     verdict: {verdict}")


def base_policy(**overrides) -> Policy:
    kwargs = dict(allowed_actions=frozenset({"read", "write", "delete"}), max_cost=100)
    kwargs.update(overrides)
    return Policy(**kwargs)


def flip_char(s: str, idx: int) -> str:
    """Replace one hex char with a different hex char."""
    c = s[idx]
    replacement = "0" if c != "0" else "1"
    return s[:idx] + replacement + s[idx + 1 :]


def main() -> int:
    workdir = Path(__file__).resolve().parent / "probe-work"
    workdir.mkdir(exist_ok=True)

    # ------------------------------------------------------------------
    # Primary kernel: accumulates the attack history used by probe 30.
    # ------------------------------------------------------------------
    primary_state = InMemoryKernelState()
    kernel = GovernanceKernel(base_policy(), secret=SECRET, state=primary_state)

    # ------------------------- Group 1: Single use -------------------------
    p = "G1"
    try:
        d = kernel.evaluate(BASE)
        first = kernel.consume(d.permit, BASE) if d.permit else None
        ok = d.outcome == "allow" and d.permit is not None and first is True
        record("01", p, "Valid permit executes once — baseline",
               "evaluate allows, permit issued, first consume returns True",
               f"outcome={d.outcome} permit_issued={d.permit is not None} consume={first}",
               "HELD" if ok else "BROKE")
        # probe 02 reuses this spent permit
        second = kernel.consume(d.permit, BASE)
        record("02", p, "Replay: same permit presented a second time",
               "second consume denied (False)",
               f"second consume={second}",
               "HELD" if second is False else "BROKE")
    except Exception as exc:  # setup failure cascades to 01 and 02
        record("01", p, "Valid permit executes once — baseline",
               "evaluate allows, permit issued, first consume returns True",
               f"EXCEPTION: {type(exc).__name__}: {exc}", "NOT RUN")
        record("02", p, "Replay: same permit presented a second time",
               "second consume denied (False)",
               "NOT RUN — baseline probe failed", "NOT RUN")

    try:
        ck = GovernanceKernel(base_policy(), secret=SECRET)  # own in-memory state
        d = ck.evaluate(BASE)
        barrier = threading.Barrier(20)

        def spend(_: int) -> bool:
            barrier.wait(timeout=30)
            return ck.consume(d.permit, BASE)

        with ThreadPoolExecutor(max_workers=20) as pool:
            outcomes = list(pool.map(spend, range(20)))
        executed = sum(1 for o in outcomes if o is True)
        record("03", p, "Concurrent replay: 20 simultaneous spends of one permit",
               "exactly 1 executed, 19 denied",
               f"executed={executed} denied={20 - executed}",
               "HELD" if executed == 1 else "BROKE")
    except Exception as exc:
        record("03", p, "Concurrent replay: 20 simultaneous spends of one permit",
               "exactly 1 executed, 19 denied",
               f"EXCEPTION: {type(exc).__name__}: {exc}", "NOT RUN")

    # Restart persistence on SQLite state (probes 04 and 05 share one restart)
    db_path = workdir / "restart-state.sqlite3"
    if db_path.exists():
        db_path.unlink()
    try:
        st1 = SQLiteKernelState(db_path)
        k1 = GovernanceKernel(base_policy(), secret=SECRET, state=st1)
        d_spent = k1.evaluate(BASE)
        spent_first = k1.consume(d_spent.permit, BASE)
        alt_intent = Intent("alice", "write", "file:/data/notes.txt", 5, "sess-1")
        d_unspent = k1.evaluate(alt_intent)
        st1.close()
        if spent_first is not True:
            raise RuntimeError(f"pre-restart spend failed: {spent_first}")
        st2 = SQLiteKernelState(db_path)
        k2 = GovernanceKernel(base_policy(), secret=SECRET, state=st2)
        again = k2.consume(d_spent.permit, BASE)
        record("04", p, "Restart persistence: spent permit stays dead after restart",
               "consume of pre-restart spent permit returns False after restart",
               f"consume after restart={again}",
               "HELD" if again is False else "BROKE")
        survives = k2.consume(d_unspent.permit, alt_intent)
        twice = k2.consume(d_unspent.permit, alt_intent)
        record("05", p, "Restart persistence: unspent permit survives, still single-use",
               "first post-restart consume True, second False",
               f"first={survives} second={twice}",
               "HELD" if (survives is True and twice is False) else "BROKE")
        st2.close()
    except Exception as exc:
        record("04", p, "Restart persistence: spent permit stays dead after restart",
               "consume of pre-restart spent permit returns False after restart",
               f"EXCEPTION: {type(exc).__name__}: {exc}", "NOT RUN")
        record("05", p, "Restart persistence: unspent permit survives, still single-use",
               "first post-restart consume True, second False",
               "NOT RUN — restart setup failed", "NOT RUN")

    try:
        d1 = kernel.evaluate(BASE)
        d2 = kernel.evaluate(BASE)
        distinct = d1.permit != d2.permit
        a1 = kernel.consume(d1.permit, BASE)
        a2 = kernel.consume(d1.permit, BASE)
        b1 = kernel.consume(d2.permit, BASE)
        b2 = kernel.consume(d2.permit, BASE)
        ok = distinct and (a1, a2, b1, b2) == (True, False, True, False)
        record("06", p, "Two permits for the same intent are distinct, each single-use",
               "permits differ; each consumes True once then False",
               f"distinct={distinct} spends=({a1},{a2},{b1},{b2})",
               "HELD" if ok else "BROKE")
    except Exception as exc:
        record("06", p, "Two permits for the same intent are distinct, each single-use",
               "permits differ; each consumes True once then False",
               f"EXCEPTION: {type(exc).__name__}: {exc}", "NOT RUN")

    # ----------------- Group 2: Bound to the exact intent -----------------
    p = "G2"
    substitutions = [
        ("07", "Resource substitution: permit for one file presented for another",
         Intent("alice", "read", "file:/data/other.txt", 10, "sess-1")),
        ("08", "Action substitution: write presented against a read permit",
         Intent("alice", "write", "file:/data/report.txt", 10, "sess-1")),
        ("09", "Cost substitution: permit presented with an altered cost",
         Intent("alice", "read", "file:/data/report.txt", 11, "sess-1")),
        ("10", "Principal substitution: permit presented by a different agent",
         Intent("bob", "read", "file:/data/report.txt", 10, "sess-1")),
        ("11", "Session substitution: permit presented under a different session",
         Intent("alice", "read", "file:/data/report.txt", 10, "sess-2")),
    ]
    for pid, name, mutated in substitutions:
        try:
            d = kernel.evaluate(BASE)
            res = kernel.consume(d.permit, mutated)
            record(pid, p, name, "consume with substituted intent denied (False)",
                   f"consume={res}", "HELD" if res is False else "BROKE")
        except Exception as exc:
            record(pid, p, name, "consume with substituted intent denied (False)",
                   f"EXCEPTION: {type(exc).__name__}: {exc}", "NOT RUN")

    # ------------------- Group 3: Forgery and tampering -------------------
    p = "G3"
    digest = GovernanceKernel.intent_hash(BASE)
    try:
        forged = f"{digest}:{secrets.token_hex(16)}:{'0' * 64}"
        res = kernel.consume(forged, BASE)
        record("12", p, "Fabricated permit in the correct format",
               "consume denied (False)", f"consume={res}",
               "HELD" if res is False else "BROKE")
    except Exception as exc:
        record("12", p, "Fabricated permit in the correct format",
               "consume denied (False)",
               f"EXCEPTION: {type(exc).__name__}: {exc}", "NOT RUN")

    try:
        nonce = secrets.token_hex(16)
        payload = f"{digest}:{nonce}"
        sig = hmac.new(ATTACKER_SECRET, payload.encode(), hashlib.sha256).hexdigest()
        res = kernel.consume(f"{payload}:{sig}", BASE)
        record("13", p, "Self-minted permit signed with an attacker's key",
               "consume denied (False)", f"consume={res}",
               "HELD" if res is False else "BROKE")
    except Exception as exc:
        record("13", p, "Self-minted permit signed with an attacker's key",
               "consume denied (False)",
               f"EXCEPTION: {type(exc).__name__}: {exc}", "NOT RUN")

    genuine_permit = None
    try:
        d = kernel.evaluate(BASE)
        genuine_permit = d.permit
        parts = genuine_permit.split(":")
        tampered = {
            "14": ("Tampered permit body (intent-hash segment)",
                   ":".join([flip_char(parts[0], 0), parts[1], parts[2]])),
            "15": ("Tampered nonce",
                   ":".join([parts[0], flip_char(parts[1], 0), parts[2]])),
            "16": ("Tampered signature",
                   ":".join([parts[0], parts[1], flip_char(parts[2], 0)])),
        }
        for pid, (name, bad_permit) in tampered.items():
            res = kernel.consume(bad_permit, BASE)
            record(pid, p, name, "consume denied (False)", f"consume={res}",
                   "HELD" if res is False else "BROKE")
    except Exception as exc:
        for pid, name in [("14", "Tampered permit body (intent-hash segment)"),
                          ("15", "Tampered nonce"),
                          ("16", "Tampered signature")]:
            record(pid, p, name, "consume denied (False)",
                   f"EXCEPTION: {type(exc).__name__}: {exc}", "NOT RUN")

    try:
        if genuine_permit is None:
            raise RuntimeError("no genuine permit available")
        res = kernel.consume(genuine_permit, BASE)
        record("17", p, "Genuine permit still works after the tamper attempts",
               "consume returns True", f"consume={res}",
               "HELD" if res is True else "BROKE")
    except Exception as exc:
        record("17", p, "Genuine permit still works after the tamper attempts",
               "consume returns True",
               f"EXCEPTION: {type(exc).__name__}: {exc}", "NOT RUN")

    try:
        d = kernel.evaluate(BASE)
        other = GovernanceKernel(base_policy(), secret=OTHER_SECRET, state=primary_state)
        res = other.consume(d.permit, BASE)
        record("18", p, "Cross-kernel: permit rejected by a kernel with a different secret (same state)",
               "consume denied (False)", f"consume={res}",
               "HELD" if res is False else "BROKE")
    except Exception as exc:
        record("18", p, "Cross-kernel: permit rejected by a kernel with a different secret (same state)",
               "consume denied (False)",
               f"EXCEPTION: {type(exc).__name__}: {exc}", "NOT RUN")

    try:
        d = kernel.evaluate(BASE)
        stranger = GovernanceKernel(base_policy(), secret=SECRET)  # fresh state
        res = stranger.consume(d.permit, BASE)
        record("19", p, "Cross-kernel: permit rejected by a kernel that never issued it",
               "consume denied (False)", f"consume={res}",
               "HELD" if res is False else "BROKE")
    except Exception as exc:
        record("19", p, "Cross-kernel: permit rejected by a kernel that never issued it",
               "consume denied (False)",
               f"EXCEPTION: {type(exc).__name__}: {exc}", "NOT RUN")

    # --------------------- Group 4: Denials issue nothing ---------------------
    p = "G4"
    denials = [
        ("20", "Unknown action", Intent("alice", "teleport", "file:/data/report.txt", 10, "sess-1")),
        ("21", "Over-budget cost", Intent("alice", "read", "file:/data/report.txt", 101, "sess-1")),
        ("22", "Incomplete intent (empty resource)", Intent("alice", "read", "", 10, "sess-1")),
        ("23", "Negative cost", Intent("alice", "read", "file:/data/report.txt", -5, "sess-1")),
        ("24", "Boolean cost (type trick)", Intent("alice", "read", "file:/data/report.txt", True, "sess-1")),
    ]
    for pid, name, intent in denials:
        try:
            d = kernel.evaluate(intent)
            ok = d.outcome == "deny" and d.permit is None
            record(pid, p, f"{name} — denied, no permit issued",
                   "evaluate outcome=deny, permit=None",
                   f"outcome={d.outcome} reason={d.reason} permit={d.permit}",
                   "HELD" if ok else "BROKE")
        except Exception as exc:
            record(pid, p, f"{name} — denied, no permit issued",
                   "evaluate outcome=deny, permit=None",
                   f"EXCEPTION: {type(exc).__name__}: {exc}", "NOT RUN")

    # ----------------- Group 5: Agent grants and expiry -----------------
    p = "G5"
    grant = AgentGrant("agent-1", frozenset({"read"}), ("repo:",), 50)
    grant_policy = Policy(
        allowed_actions=frozenset({"read", "write"}),
        max_cost=1000,
        agent_grants=(grant,),
    )
    gk = GovernanceKernel(grant_policy, secret=SECRET)
    grant_denials = [
        ("25", "Agent exceeding its granted action",
         Intent("agent-1", "write", "repo:thing", 10, "sess-1")),
        ("26", "Agent exceeding its granted budget",
         Intent("agent-1", "read", "repo:thing", 51, "sess-1")),
        ("27", "Agent reaching outside its granted resources",
         Intent("agent-1", "read", "evidence:thing", 10, "sess-1")),
        ("28", "Unknown agent principal",
         Intent("mallory", "read", "repo:thing", 10, "sess-1")),
    ]
    for pid, name, intent in grant_denials:
        try:
            d = gk.evaluate(intent)
            ok = d.outcome == "deny" and d.permit is None
            record(pid, p, f"{name} — denied",
                   "evaluate outcome=deny, permit=None",
                   f"outcome={d.outcome} reason={d.reason} permit={d.permit}",
                   "HELD" if ok else "BROKE")
        except Exception as exc:
            record(pid, p, f"{name} — denied",
                   "evaluate outcome=deny, permit=None",
                   f"EXCEPTION: {type(exc).__name__}: {exc}", "NOT RUN")

    try:
        now = [1_700_000_000_000_000_000]  # fixed fake clock, ns
        ttl_policy = base_policy(permit_ttl_ns=2_000_000_000)  # 2 seconds
        ek = GovernanceKernel(ttl_policy, secret=SECRET, clock=lambda: now[0])
        d = ek.evaluate(BASE)
        now[0] += 3_000_000_000  # advance 3 s, past the 2 s TTL
        res = ek.consume(d.permit, BASE)
        record("29", p, "Expired permit rejected at spend time",
               "consume after TTL returns False",
               f"permit_issued={d.permit is not None} consume_after_expiry={res}",
               "HELD" if res is False else "BROKE")
    except Exception as exc:
        record("29", p, "Expired permit rejected at spend time",
               "consume after TTL returns False",
               f"EXCEPTION: {type(exc).__name__}: {exc}", "NOT RUN")

    # ------------------------- Group 6: Audit trail -------------------------
    p = "G6"
    try:
        valid = kernel.verify_audit()
        record("30", p, "Audit chain verifies clean after every attack above",
               "verify_audit() returns True on the primary kernel",
               f"verify_audit={valid} records={len(kernel.audit)}",
               "HELD" if valid is True else "BROKE")
    except Exception as exc:
        record("30", p, "Audit chain verifies clean after every attack above",
               "verify_audit() returns True on the primary kernel",
               f"EXCEPTION: {type(exc).__name__}: {exc}", "NOT RUN")

    try:
        tk = GovernanceKernel(base_policy(), secret=SECRET)
        tk.evaluate(BASE)
        before = tk.verify_audit()
        # WHITE-BOX check (labelled as such in the Oct 31 write-up):
        # mutate one stored audit record's payload in place, then re-verify.
        tk._state.audit[0]["payload"]["reason"] = "tampered-by-probe"
        after = tk.verify_audit()
        ok = before is True and after is False
        record("31", p, "Direct audit-record tampering detected (white-box check)",
               "verify_audit() True before tamper, False after",
               f"before={before} after={after}",
               "HELD" if ok else "BROKE")
    except Exception as exc:
        record("31", p, "Direct audit-record tampering detected (white-box check)",
               "verify_audit() True before tamper, False after",
               f"EXCEPTION: {type(exc).__name__}: {exc}", "NOT RUN")

    # ------------------------------ Summary ------------------------------
    held = sum(1 for r in RESULTS if r["verdict"] == "HELD")
    broke = sum(1 for r in RESULTS if r["verdict"] == "BROKE")
    notrun = sum(1 for r in RESULTS if r["verdict"] == "NOT RUN")
    print()
    print(f"PROBE SUMMARY: total={len(RESULTS)} held={held} broke={broke} not_run={notrun}")

    out = Path(__file__).resolve().parent / "probes-results.json"
    out.write_text(json.dumps(RESULTS, indent=2), encoding="utf-8")
    print(f"Machine-readable results written to {out.name}")
    return 0 if broke == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
