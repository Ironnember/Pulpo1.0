# Pulpo-Preview reproduction run — comparison against the Oct 31, 2026 record

Run by SHAETHON AI, November 3, 2026. Source: Pulpo-Preview release asset
`pulpo-linux-source-ec5270876c6db57c2cf58d9383001b1d7a9e08c1.tar.gz`
(pre-release `pulpo-linux-v0.1.0-ubuntu-evaluation.20261031`), SHA-256
`358c2c6322c7ce22fb5a735cee2aa6ab448231a0b3a8a86c4de1c9cbcd21ffb2` — computed
hash matches the publisher-stated hash on the release page; commit
`ec5270876c6db57c2cf58d9383001b1d7a9e08c1`. Same asset, same commit, and same
method (repository's unittest validation commands, scrubbed environment,
root on a Linux VM, Python 3.12.3) as the Oct 31 run.

## Divergence — stated plainly, first

**One divergence, and it is small and favourable.** In the core suite, four
tests that were *skipped* on Oct 31 *ran and passed* in this run. Everything
else in the headline counts is identical: same tests ran (1,024), same
failures (4), same errors (24). The 31 boundary probes reproduced exactly:
31 held, 0 broke, on both runs.

A test-by-test diff against Oct 31 is not possible: the original run's raw
log was not retained (see COVER-NOTE.md), so this comparison is made at the
level the Oct 31 record actually preserves — counts, and the failure/error
clusters by test module and cause. At that level the two runs agree, as
detailed below.

## Suite counts — core suite (the Oct 31 headline scope)

`python -W error -m unittest discover -s tests -v`

| Metric | Oct 31, 2026 | Nov 3, 2026 (this run) |
|---|---|---|
| Tests ran | 1,024 | 1,024 |
| Passed | 936 | 940 |
| Skipped | 60 | 56 |
| Failures | 4 | 4 |
| Errors | 24 | 24 |
| Wall time | ~76 s | 77.8 s |

## Failure / error clusters — core suite

All 28 non-passing results (4 failures + 24 errors) sit outside the permit,
governance, and verifier kernel suites in both runs, in the same modules,
for the same environment-bound reasons. Causes verified from this run's
tracebacks:

| Test module | Count | Cause (verified in this run's log) |
|---|---|---|
| test_archive_prototype | 15 errors | Requires a live git checkout (`git rev-parse HEAD`); a source tarball is not one |
| test_installation_observation | 3 failures + 3 errors | Root / file-permission-bit posture of the sandbox |
| test_dark_mirror_proof_v0 | 3 errors | Git-checkout-dependent fixture (same class as above) |
| test_crash_backend_loading | 1 failure | `git show <rev>:pulpo/state.py` — needs a git checkout |
| test_temporal_transfer_proof_zero | 1 error (setUpClass) | `git show <freeze-commit>:...` — needs a git checkout |
| test_wsl_package | 1 error | WSL packaging; also calls `git rev-parse HEAD` |
| test_disk_service_recovery | 1 error | Fixture refuses volatile-memory storage ("disk fixture must not use volatile memory storage") on this VM |

This matches the Oct 31 record's own categorisation (installation-observation,
WSL-package, archive-fixture, crash-backend-loading, disk-recovery,
dark-mirror, and temporal-transfer clusters; none in the kernel suites).
The standing expectation is unchanged: a rerun as a non-root user in a real
git clone should close most or all of this gap. That rerun remains a
separate, future pass.

## Additional suites run Nov 3 (no Oct 31 counterpart in the record)

The Oct 31 headline number covered the core discover only. For completeness
this run also executed the repository's remaining published validation
commands, with the services' own dependencies installed per their
pyprojects:

| Suite | Result |
|---|---|
| Constitutional sequences (`tests.test_constitutional_sequences`) | 1 test ran, OK (54.1 s) |
| authority-service (`unittest discover -s authority-service/tests`) | 70 ran, OK, 4 skipped |
| custody-service (`unittest discover -s custody-service/tests`) | 50 ran, OK |

## Method notes (so the numbers can be read correctly)

- **Scrubbed environment.** The run used `env -i` with a minimal PATH and a
  sandbox HOME — the Oct 31 method. A first pass in the agent shell's
  ambient environment produced 9 extra errors in test_authority_client and
  test_external_response_bounds: ambient CA-bundle variables in that shell
  trip Pulpo's fail-closed transport check
  (`ambient_ca_configuration_requires_pulpo_ca_bundle`). That pass was
  discarded and is not in this package; the enclosed suite log is the
  scrubbed run, and its header records this.
- **Runner.** Counts were produced with the repository's own unittest
  commands (the publisher's validation method, and the Oct 31 method), not
  pytest, so the numbers compare like-for-like.
- **Publisher's claim.** The release page states 1,030 tests passed in the
  publisher's own environment (GitHub-hosted Ubuntu / WSL2, Python 3.14.4 /
  3.12.15). Our independent runs — Oct 31 and Nov 3 alike — reproduce 1,024
  core tests with the environment-bound residue described above.

## Boundary probes — Oct 31 vs Nov 3

All 31 probes were re-implemented from the Oct 31 write-up's specification
against the kernel's public API (probe 31 is the same explicitly white-box
audit-tamper check as the original). Full per-probe output is in
`probes-raw-output.txt` and `probes-results.json`.

| Result | Oct 31, 2026 | Nov 3, 2026 |
|---|---|---|
| Held | 31 | 31 |
| Broke | 0 | 0 |
| Not run | 0 | 0 |

Per-probe detail follows.

| # | Group | Probe | Oct 31 | Nov 3 |
|---|---|---|---|---|
| 01 | G1 | Valid permit executes once — baseline | HELD | HELD |
| 02 | G1 | Replay: same permit presented a second time | HELD | HELD |
| 03 | G1 | Concurrent replay: 20 simultaneous spends of one permit | HELD | HELD |
| 04 | G1 | Restart persistence: spent permit stays dead after restart | HELD | HELD |
| 05 | G1 | Restart persistence: unspent permit survives, still single-use | HELD | HELD |
| 06 | G1 | Two permits for the same intent are distinct, each single-use | HELD | HELD |
| 07 | G2 | Resource substitution: permit for one file presented for another | HELD | HELD |
| 08 | G2 | Action substitution: write presented against a read permit | HELD | HELD |
| 09 | G2 | Cost substitution: permit presented with an altered cost | HELD | HELD |
| 10 | G2 | Principal substitution: permit presented by a different agent | HELD | HELD |
| 11 | G2 | Session substitution: permit presented under a different session | HELD | HELD |
| 12 | G3 | Fabricated permit in the correct format | HELD | HELD |
| 13 | G3 | Self-minted permit signed with an attacker's key | HELD | HELD |
| 14 | G3 | Tampered permit body (intent-hash segment) | HELD | HELD |
| 15 | G3 | Tampered nonce | HELD | HELD |
| 16 | G3 | Tampered signature | HELD | HELD |
| 17 | G3 | Genuine permit still works after the tamper attempts | HELD | HELD |
| 18 | G3 | Cross-kernel: permit rejected by a kernel with a different secret (same state) | HELD | HELD |
| 19 | G3 | Cross-kernel: permit rejected by a kernel that never issued it | HELD | HELD |
| 20 | G4 | Unknown action — denied, no permit issued | HELD | HELD |
| 21 | G4 | Over-budget cost — denied, no permit issued | HELD | HELD |
| 22 | G4 | Incomplete intent (empty resource) — denied, no permit issued | HELD | HELD |
| 23 | G4 | Negative cost — denied, no permit issued | HELD | HELD |
| 24 | G4 | Boolean cost (type trick) — denied, no permit issued | HELD | HELD |
| 25 | G5 | Agent exceeding its granted action — denied | HELD | HELD |
| 26 | G5 | Agent exceeding its granted budget — denied | HELD | HELD |
| 27 | G5 | Agent reaching outside its granted resources — denied | HELD | HELD |
| 28 | G5 | Unknown agent principal — denied | HELD | HELD |
| 29 | G5 | Expired permit rejected at spend time | HELD | HELD |
| 30 | G6 | Audit chain verifies clean after every attack above | HELD | HELD |
| 31 | G6 | Direct audit-record tampering detected (white-box check) | HELD | HELD |

Every probe's observed behaviour in this run is recorded verbatim in
`probes-raw-output.txt` (and `probes-results.json`), including the kernel's
own denial reasons (e.g. `incomplete_intent`, `invalid_cost`,
`agent_budget_exceeded`, `unknown_principal`).
