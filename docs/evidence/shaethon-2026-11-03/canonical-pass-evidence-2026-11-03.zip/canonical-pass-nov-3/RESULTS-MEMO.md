# Canonical-main independent reproduction — RESULTS (Nov 3, 2026, night)

Executed by Geas (SHAETHON AI) under Austin's INDEPENDENT_REPRODUCTION.md protocol,
on Seth's word the night of Nov 3, 2026. Reviewer posture: independent, hostile witness,
competitor — same as the Preview pass.

## Object
- Repo: Ironnember/Pulpo1.0, fresh clone, detached checkout.
- HEAD: 6b3caacbc28a7b40ebf5ea6295bc8058804de6e3 ✓ (exact)
- Tree: df6310dc0b6eaec50b7870832dd8cb379096f778 ✓ (exact, matches protocol expectation)
- PR #338 did not move the target: pass ran against 6b3caac regardless, per the Nov 3 answer.

## Environment
- Host: Linux htch-runtime 7.0.0-39-generic x86_64 (Ubuntu 24.04.5 LTS VM).
- Run as NON-ROOT user `pulpo` (uid 1000), per protocol calibration.
- Python 3.11.14 (uv-managed CPython, installed for this run; host's system Python is 3.12).
- Repo AGENTS.md read before running. All output kept outside the checkout.

## Results (protocol order)
1. **Unittest suite** — `python3.11 -W error -m unittest discover -s tests -v`
   **422 ran in 29.77s — OK. 4 skipped, 0 failures, 0 errors.**
   Skips: 3× Ed25519 authority tests (optional dependency absent in the bare env —
   resolved separately below, NOT silently omitted) and 1× macOS Seatbelt test
   ('requires actual macOS Seatbelt' — platform prerequisite this Linux host cannot meet;
   reported as untested, not passed).
2. **Asymmetric-verifier tests (isolated env)** — venv with cryptography==50.0.1 exactly:
   `tests.test_authority_crypto` — **3 ran, OK.** The 3 suite skips are closed.
3. **Gladiator tournament** — exit 0. **FINAL: PASS_WITH_BOUNDARIES, 138 test executions,
   10,600 scheduled mixed operations, 0 failures/errors/skips** across all phases;
   tournament-results.json records source_unchanged: true, clean_tree_after: true.
   (Scheduled operations are not 10,600 unique attacks — protocol's own wording.)
4. **Synthetic incident proof** — exit 0. **PASS: 14/14 checks, remediation_count exactly 1.**
   SQLite DB + JSON evidence preserved (incident-state/ in this folder).
5. **compileall** — exit 0.
6. **git diff --check** vs empty-tree hash — exit 0. **git status --porcelain: empty**
   before and after — tracked source unchanged. HEAD/tree re-verified at the end: exact.

## Acceptance check (protocol's own criteria)
- Exact commit + tree: ✓. Source unchanged: ✓.
- Tournament PASS_WITH_BOUNDARIES with 138 / 10,600 / clean flags: ✓.
- Incident proof 14/14 + exactly one remediation + preserved DB: ✓.
- All skips/failures explicitly reported: ✓ (macOS Seatbelt path untested on this host;
  service/container suites in .github/workflows/ci.yml were NOT run — the core suite does
  not establish them, per the protocol itself).
- Denial / positive control / substitution / replay / revocation / UNKNOWN case classes are
  exercised inside the suite and tournament evidence itself. A separate SHAETHON adversarial
  battery on top of canonical main was welcomed by the protocol but is NOT part of this run;
  the Oct 31 31-probe battery remains a Preview-build artifact. Stated plainly so the record
  does not overclaim.

## Verdict
**Canonical main @ 6b3caac REPRODUCES under its own protocol on an independent host.**
Every acceptance number Austin published was met exactly: 422-suite green (with the crypto
module closed in its isolated env), PASS_WITH_BOUNDARIES 138/10,600, incident proof 14/14/1.
The one untested path is macOS Seatbelt (platform), and the service/container CI suites
remain outside this run's scope — both stated in the protocol's own limits.

## Evidence (this folder: canonical-pass-nov-3/)
- env.txt, unittest.log (sha256 ace1b4cd…), gladiator.log (2d97cf41…), incident.log (0d9c5dd7…),
  crypto.log (cbb67438…), tournament-results.json (d6c846ca…), incident-result.json,
  incident-state/pulpo-synthetic-incident-response.sqlite3 (a6e13d17…).

## Status
- NOT yet sent to Austin — Seth's word required, same as the reconciliation memo pattern.
  (The reconciliation verdict email went out Nov 3, 10:11 PM; this pass is the next deliverable.)
